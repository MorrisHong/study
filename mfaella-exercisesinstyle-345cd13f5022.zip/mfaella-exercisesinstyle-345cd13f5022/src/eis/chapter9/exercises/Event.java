package eis.chapter9.exercises;

/**
 * Exercise 3 from chapter 9.
 * 
 * @author Marco Faella
 * @version 1.0
 */
public interface Event {
    void start();
    void stop();
}
